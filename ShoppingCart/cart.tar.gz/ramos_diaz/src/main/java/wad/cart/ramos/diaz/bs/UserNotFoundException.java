package wad.cart.ramos.diaz.bs;

public class UserNotFoundException extends Exception{
}
