package wad.cart.ramos.diaz.bs;

public class WrongPasswordException extends Exception{
}