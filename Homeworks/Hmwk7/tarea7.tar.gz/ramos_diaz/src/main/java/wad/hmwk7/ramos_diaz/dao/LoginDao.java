package wad.hmwk7.ramos_diaz.dao;

public class LoginDao {

	public LoginDao() {
		// TODO Auto-generated constructor stub
	}

}
