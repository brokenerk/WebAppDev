package wad.hmwk7.ramos_diaz.bs;

public class LoginBs {

	public LoginBs() {
		// TODO Auto-generated constructor stub
	}

}
