package wad.hmwk7.ramos_diaz.dao;

public class UsersTableDao {

	public UsersTableDao() {
		// TODO Auto-generated constructor stub
	}

}
