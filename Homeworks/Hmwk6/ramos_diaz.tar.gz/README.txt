Carpeta del proyecto en Eclipse: "tarea6"

URL Index: http://localhost:8080/tarea6/

Nombre de la BD: homework-6
Usuario: postgres
Contraseña: postgres

WAD - Tarea 6
Alumno: Ramos Diaz Enrique
Grupo: 3CM6