package mx.ipn.escom.wad.tarea6.exception;

public class NombreObjetosSession {
	public static final String USER = "authenticated_user";
}
