package mx.ipn.escom.wad.bs;

public class LoginDuplicatedException extends Exception{

}
