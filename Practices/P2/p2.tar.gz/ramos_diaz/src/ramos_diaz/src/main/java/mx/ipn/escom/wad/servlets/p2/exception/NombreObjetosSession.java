package mx.ipn.escom.wad.servlets.p2.exception;

public class NombreObjetosSession {
	public static final String USER = "authenticated_user";
}
