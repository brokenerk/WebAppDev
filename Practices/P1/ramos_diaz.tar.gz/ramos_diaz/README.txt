Carpeta del proyecto en Eclipse: "ramos_diaz". Dentro de la carpeta "src"

La base de datos "homework-6" debe cargarse antes de lanzar el proyecto en Jetty

URL Index: http://localhost:8080/ramos_diaz/

WAD - Práctica 1
Alumno: Ramos Diaz Enrique
Grupo: 3CM6